<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");
$APPLICATION->SetTitle("clocks");
?><?$APPLICATION->IncludeComponent(
	"user:clock",
	".default",
	Array(
		"COMPONENT_TEMPLATE" => ".default",
		"DATE_AND_TIME" => "d/m/Y H:i:s",
		"INIT_TIME" => "",
		"INPUT_ID" => "",
		"INPUT_NAME" => "",
		"SHOW_DATE" => "",
		"SHOW_DATE_TIME_ZONE" => "(GMT-04:30) Caracas"
	)
);?>
<?$APPLICATION->IncludeComponent(
	"user:clock",
	"Templ1",
	Array(
		"COMPONENT_TEMPLATE" => "Templ1",
		"DATE_AND_TIME" => "d/m/Y H:i:s",
		"INIT_TIME" => "",
		"INPUT_ID" => "",
		"INPUT_NAME" => "",
		"SHOW_DATE" => "",
		"SHOW_DATE_TIME_ZONE" => "(GMT-04:30) Caracas"
	)
);?><br><?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php");?>