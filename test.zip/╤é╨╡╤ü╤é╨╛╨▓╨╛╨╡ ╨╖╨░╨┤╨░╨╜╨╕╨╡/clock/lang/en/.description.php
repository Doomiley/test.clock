<?
$MESS ['MAIN_CLOCK_COMPONENT_NAME'] = "Time and date";
$MESS ['MAIN_CLOCK_COMPONENT_DESCR'] = "Component for Time and date";
?>