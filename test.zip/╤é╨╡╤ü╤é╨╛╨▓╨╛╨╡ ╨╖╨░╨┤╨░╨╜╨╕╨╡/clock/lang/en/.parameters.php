<?
$MESS ['COMP_CLOCK_INPUT_ID'] = "Input Field ID";
$MESS["T_IBLOCK_DESC_ACTIVE_DATE_FORMAT"] = "Format show data";
?>