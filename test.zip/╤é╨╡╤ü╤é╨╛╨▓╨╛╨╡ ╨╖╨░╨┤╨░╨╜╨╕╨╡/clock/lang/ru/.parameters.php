<?
$MESS ['COMP_CLOCK_INPUT_ID'] = "ID поля ввода";
$MESS["T_IBLOCK_DESC_ACTIVE_DATE_FORMAT"] = "Формат показа даты";
?>