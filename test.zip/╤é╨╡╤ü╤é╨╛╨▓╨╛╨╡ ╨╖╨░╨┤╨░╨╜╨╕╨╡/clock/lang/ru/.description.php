<?
$MESS ['MAIN_CLOCK_COMPONENT_NAME'] = " \"дата и время\"";
$MESS ['MAIN_CLOCK_COMPONENT_DESCR'] = "Компонент для вывода даты и времени";
?>