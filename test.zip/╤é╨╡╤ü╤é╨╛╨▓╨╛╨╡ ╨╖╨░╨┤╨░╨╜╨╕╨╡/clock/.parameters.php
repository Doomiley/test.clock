<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();

 include 'timezonelist.php';

$arComponentParameters = array(
	"PARAMETERS" => array(
		"SHOW_DATE_TIME_ZONE" => array(
			"NAME" => "Часовой пояс",
			"TYPE" => "LIST",
			"VALUES" => $zzz,
			"DEFAULT" => "",
			"PARENT" => "BASE"
			),
		"DATE_AND_TIME" => array (
			"NAME" => "Формат даты и времени",	
			"TYPE" => "LIST",
			"VALUES" => array (
			"d/m/Y H:i:s" => "d/m/Y H:i:s",
			"d-m-Y H:i:s" => "d-m-Y H:i:s"
			),
			"DEFAULT" => "",
			"PARENT" => "BASE"
		),
	),
);
?>