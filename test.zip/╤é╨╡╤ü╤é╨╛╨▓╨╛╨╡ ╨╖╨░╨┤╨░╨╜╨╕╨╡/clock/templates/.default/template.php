<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();?>
<html>

<body>

<table width="100%" height="100%" border=0><tr valign="middle"><td align="center"></br>Сегодня: '.<? echo $arResult['dt'] ?>.'</td></tr></table>

</body>

</html>

