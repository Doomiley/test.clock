<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();?>
<html>

<body>

<table width="100%" height="100%" border=0><tr valign="middle"><td align="center"><font size="5" color="blue" face="Arial"></br>Сегодня: '.<? echo $arResult['dt'] ?>.'</font></td></tr></table>

</body>

</html>

