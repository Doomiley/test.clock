<?
if(!defined("B_PROLOG_INCLUDED")||B_PROLOG_INCLUDED!==true)die();

 include 'timezonelist.php';

$clockParams = array();
if ($arParams['SHOW_DATE_TIME_ZONE'])
	$clockParams['showDateTimeZone'] = $arParams['SHOW_DATE_TIME_ZONE'];
if ($arParams['DATE_AND_TIME'])
	$clockParams['dateAndTime'] = $arParams['DATE_AND_TIME'];
	
$arResult['clockParams'] = $clockParams;

	$tz = $arResult['clockParams']['showDateTimeZone'];
		$timestamp = time();
	$dt = new DateTime("now", new DateTimeZone($tz)); 
	$dt->setTimestamp($timestamp);
	$dt->format($arResult['clockParams']['dateAndTime']);

$arResult['dt'] = $dt -> format($arResult['clockParams']['dateAndTime']);

$this->IncludeComponentTemplate();

?>